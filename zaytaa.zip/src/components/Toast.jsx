import { useEffect } from "react";

export default function Toast({ message, onClose }) {
	// Automatically close after 3 seconds
	useEffect(() => {
		const timer = setTimeout(onClose, 3000);
		return () => clearTimeout(timer);
	}, [onClose]);

	// If there is no message, render absolutely nothing! (Fixes the "always showing" bug)
	if (!message) return null;

	return (
		<div className="axio-toast" style={styles.toast}>
			<div style={styles.contentWrap}>
				<span style={styles.icon}>✓</span>
				<span style={styles.message}>{message}</span>
			</div>

			{/* The Manual Close Button */}
			<button onClick={onClose} style={styles.closeBtn}>
				✕
			</button>

			<style>{`
                /* Changed to slide down from the TOP */
                @keyframes slideDown { 
                    from { transform: translateY(-100%); opacity: 0; } 
                    to { transform: translateY(0); opacity: 1; } 
                }
                .axio-toast { 
                    animation: slideDown 0.3s ease-out forwards; 
                }
                
                /* Simple hover effect for the close button */
                .axio-close-btn:hover {
                    color: white !important;
                }
            `}</style>
		</div>
	);
}

const styles = {
	toast: {
		position: "fixed",
		top: "24px", // ---> CHANGED: Now drops from the top
		right: "24px",
		background: "var(--ink)",
		color: "white",
		padding: "12px 16px 12px 24px", // Adjusted padding to fit the button nicely
		borderRadius: "8px",
		display: "flex",
		alignItems: "center",
		justifyContent: "space-between", // Pushes the close button to the far right
		minWidth: "250px",
		boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
		zIndex: 9999,
	},
	contentWrap: {
		display: "flex",
		alignItems: "center",
		gap: "12px",
	},
	icon: { color: "var(--green)", fontSize: "16px" },
	message: {
		fontFamily: "var(--font-sans)",
		fontSize: "14px",
		fontWeight: 600,
		color: "white",
	},

	// Styling for the new X button
	closeBtn: {
		background: "none",
		border: "none",
		color: "#a8a29e", // var(--stone) equivalent
		fontSize: "16px",
		cursor: "pointer",
		padding: "4px 8px",
		marginLeft: "16px",
		transition: "color 0.2s ease",
	},
};
